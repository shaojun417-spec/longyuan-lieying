/**
 * 龍淵裂影 - Cloudflare Workers
 *
 * 端點：
 *   POST /api/video-info    解析網址，回傳無水印影片 URL
 *   GET  /api/dl-stream     代理下載（繞過瀏覽器 Referer 限制）
 *   GET  /health
 *
 * 設計：
 *   - 全部自己抓（不靠任何第三方解析 API）
 *   - 抖音走 a-bogus 純算簽名打官方 API
 *   - 支援網頁網址（會跟隨跳轉，找出影片 ID）
 */

import { generateABogus } from './abogus.js';

// ===================== 工具 =====================

function detectPlatform(text) {
  const u = text.toLowerCase();
  if (u.includes('douyin.com') || u.includes('iesdouyin.com')) return 'douyin';
  if (u.includes('xiaohongshu.com') || u.includes('xhslink.com')) return 'xiaohongshu';
  if (u.includes('tiktok.com') || u.includes('vm.tiktok')) return 'tiktok';
  if (u.includes('youtube.com') || u.includes('youtu.be')) return 'youtube';
  return 'unknown';
}

function extractUrl(raw) {
  const m = raw.match(/https?:\/\/[^\s\u4e00-\u9fff\u3000-\u303f\uff00-\uffef]+/);
  if (m) return m[0].replace(/[,，。、)\]}>]+$/, '');
  return raw.trim();
}

async function fetchFollowing(url, ua) {
  const r = await fetch(url, {
    headers: { 'User-Agent': ua, 'Accept': 'text/html,application/json,*/*' },
    redirect: 'follow',
  });
  return { finalUrl: r.url, html: await r.text(), status: r.status };
}

function stripWatermark(url) {
  return url
    .replace(/watermark=1/g, 'watermark=0')
    .replace(/\\u002F/g, '/')
    .replace(/\\\//g, '/');
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Cache-Control': 'no-store',
    },
  });
}

// ===================== 抖音（a-bogus 路線） =====================

const UA_DOUYIN = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36";

async function parseDouyin(rawText) {
  const url = extractUrl(rawText);

  try {
    // 1) 跟隨短網址跳轉
    const { finalUrl, html } = await fetchFollowing(url, UA_DOUYIN);

    // 2) 從 HTML 抓 aweme_id
    const patterns = [
      /"aweme_id":"(\d+)"/,
      /\/video\/(\d{15,20})/,
      /"itemId"\s*:\s*"(\d+)"/,
      /window\.__INITIAL_STATE__\s*=\s*({.+?});\s*</,
    ];
    let awemeId = null;
    for (const p of patterns) {
      const m = html.match(p);
      if (m && p.source.includes('aweme_id')) {
        awemeId = m[1];
        break;
      }
    }
    // 另一種：URL 路徑裡直接有 (例如 modal_id=xxx)
    if (!awemeId) {
      const u = new URL(finalUrl);
      const mid = u.searchParams.get('modal_id');
      if (mid && /^\d+$/.test(mid)) awemeId = mid;
    }

    if (!awemeId) {
      return {
        success: false,
        platform: 'douyin',
        error: '找不到影片 ID',
        error_hint: '請貼抖音 App「分享 → 複製連結」那整段文字',
      };
    }

    // 3) 打抖音 API 拿影片詳情
    const queryParams = {
      device_platform: 'webapp',
      aid: '6383',
      channel: 'channel_pc_web',
      aweme_id: awemeId,
      pc_client_type: '1',
      version_code: '190500',
      version_name: '19.5.0',
      cookie_enabled: 'true',
      screen_width: '1920',
      screen_height: '1080',
      browser_language: 'zh-CN',
      browser_platform: 'Win32',
      browser_name: 'Chrome',
      browser_version: '130.0.0.0',
      browser_online: 'true',
      engine_name: 'Blink',
      engine_version: '130.0.0.0',
      os_name: 'Windows',
      os_version: '10',
      cpu_core_num: '16',
      device_memory: '8',
      platform: 'PC',
      downlink: '10',
      effective_type: '4g',
      round_trip_time: '0',
      webid: String(Math.floor(Math.random() * 9e15) + 1e14),
    };
    const paramStr = Object.entries(queryParams)
      .map(([k, v]) => `${k}=${v}`)
      .join('&');

    // 4) 算 a-bogus
    const aBogus = generateABogus(paramStr, '', UA_DOUYIN);
    const fullUrl = `https://www.douyin.com/aweme/v1/web/aweme/detail/?${paramStr}&a_bogus=${aBogus}`;

    // 5) 打 API
    const apiResp = await fetch(fullUrl, {
      headers: {
        'User-Agent': UA_DOUYIN,
        'Referer': 'https://www.douyin.com/',
        'Cookie': 'ttwid=1%7Cxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
      },
    });
    const data = await apiResp.json();

    if (data.status_code !== 0 || !data.aweme_detail) {
      return {
        success: false,
        platform: 'douyin',
        error: '抖音 API 拒絕請求',
        error_hint: `status_code=${data.status_code}, status_msg=${data.status_msg || 'unknown'}`,
      };
    }

    const aweme = data.aweme_detail;
    // 抖音會回傳多種解析度，這裡挑 play_addr（無浮水印）最大的 mp4
    let playUrl = '';
    const candidates = [
      aweme.video?.play_addr?.url_list,
      aweme.video?.play_addr_lowbr?.url_list,
      aweme.video?.download_addr?.url_list,
    ];
    for (const c of candidates) {
      if (Array.isArray(c) && c.length) {
        playUrl = c[0];
        break;
      }
    }
    if (!playUrl) {
      return {
        success: false,
        platform: 'douyin',
        error: '影片已下架或被設為私密',
        error_hint: 'aweme_id=' + awemeId,
      };
    }

    return {
      success: true,
      url: stripWatermark(playUrl),
      title: aweme.desc || `抖音影片 ${awemeId}`,
      thumbnail: aweme.video?.cover?.url_list?.[0] || aweme.video?.origin_cover?.url_list?.[0] || '',
      duration: aweme.video?.duration || 0,
      fileSize: aweme.video?.play_addr?.data_size || 0,
      platform: 'douyin',
      uploader: aweme.author?.nickname || '',
    };
  } catch (e) {
    return {
      success: false,
      platform: 'douyin',
      error: '解析失敗',
      error_hint: e.message || String(e),
    };
  }
}

// ===================== 小紅書 =====================

async function parseXiaohongshu(rawText) {
  const url = extractUrl(rawText);
  const ua = 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148';

  try {
    const { html } = await fetchFollowing(url, ua);

    const m = html.match(/window\.__INITIAL_STATE__\s*=\s*(\{.+?\});\s*</);
    if (!m) {
      return {
        success: false,
        platform: 'xiaohongshu',
        error: '抓不到小紅書頁面資料',
        error_hint: '建議貼影片分享文字',
      };
    }

    const text = m[1].replace(/\\u002F/g, '/').replace(/\\\//g, '/').replace(/\\"/g, '"');
    const urlMatch = text.match(/"(?:masterUrl|videoUrl|backupUrls)":"(https?:\/\/[^"]+\.mp4[^"]*)"/);
    let videoUrl = urlMatch ? urlMatch[1] : '';
    if (!videoUrl) {
      const directMatch = html.match(/(https?:\/\/sns-video[^"'\s]+\.mp4)/);
      if (directMatch) videoUrl = directMatch[1];
    }

    if (!videoUrl) {
      return {
        success: false,
        platform: 'xiaohongshu',
        error: '無法取得影片連結',
        error_hint: '小紅書未登入請求受限',
      };
    }

    const title = (text.match(/"title":"([^"]+)"/) || [, ''])[1] ||
                  (text.match(/"desc":"([^"]+)"/) || [, ''])[1] || '小紅書影片';
    const cover = (text.match(/"imageDefault":"([^"]+)"/) || [, ''])[1] || '';
    const author = (text.match(/"nickname":"([^"]+)"/) || [, ''])[1] || '';

    return {
      success: true,
      url: videoUrl,
      title,
      thumbnail: cover,
      duration: 0,
      platform: 'xiaohongshu',
      uploader: author,
    };
  } catch (e) {
    return { success: false, platform: 'xiaohongshu', error: '解析失敗', error_hint: e.message };
  }
}

// ===================== TikTok =====================

async function parseTikTok(rawText) {
  const url = extractUrl(rawText);
  const ua = 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148';

  try {
    const { html } = await fetchFollowing(url, ua);
    const m = html.match(/<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>([^<]+)<\/script>/);
    if (!m) {
      return { success: false, platform: 'tiktok', error: '抓不到 TikTok 頁面資料', error_hint: '請試試其他平台' };
    }

    const data = JSON.parse(m[1].replace(/undefined/g, 'null'));
    const item = data?.['__DEFAULT_SCOPE__']?.['webapp.video-detail']?.itemInfo?.itemStruct;
    if (!item) {
      return { success: false, platform: 'tiktok', error: '頁面結構變了' };
    }

    const playUrl = item.video?.playAddr?.[0] || item.video?.downloadAddr?.[0] || '';
    return {
      success: true,
      url: playUrl,
      title: item.desc || 'TikTok 影片',
      thumbnail: item.video?.cover?.[0] || '',
      duration: item.video?.duration || 0,
      platform: 'tiktok',
      uploader: item.author?.nickname || '',
    };
  } catch (e) {
    return { success: false, platform: 'tiktok', error: '解析失敗', error_hint: e.message };
  }
}

// ===================== YouTube =====================

function parseYouTube(rawText) {
  return {
    success: false,
    platform: 'youtube',
    error: 'YouTube 不支援直接下載',
    error_hint: '請用 yt-dlp 等工具',
  };
}

// ===================== 主路由 =====================

async function handleVideoInfo(request) {
  if (request.method !== 'POST') {
    return json({ success: false, error: '請使用 POST' }, 405);
  }

  let body;
  try { body = await request.json(); } catch { return json({ success: false, error: 'JSON 格式錯誤' }, 400); }

  const raw = body.url?.trim();
  if (!raw) return json({ success: false, error: '請提供網址' }, 400);

  const platform = detectPlatform(raw);
  let result;

  switch (platform) {
    case 'douyin':      result = await parseDouyin(raw); break;
    case 'xiaohongshu': result = await parseXiaohongshu(raw); break;
    case 'tiktok':      result = await parseTikTok(raw); break;
    case 'youtube':     result = parseYouTube(raw); break;
    default:
      result = { success: false, platform: 'unknown', error: '不支援的影片平台', error_hint: '目前支援：抖音、小紅書、TikTok、YouTube' };
  }

  return json(result, result.success ? 200 : 400);
}

// ===================== 代理下載 =====================

async function handleDlStream(request) {
  const url = new URL(request.url);
  const target = url.searchParams.get('url');
  const referer = url.searchParams.get('referer') || 'https://www.douyin.com/';
  const filename = url.searchParams.get('filename') || 'video.mp4';

  if (!target) return new Response('missing url', { status: 400 });

  try {
    const upstream = await fetch(target, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Referer': referer,
      },
    });
    if (!upstream.ok || !upstream.body) return new Response('upstream ' + upstream.status, { status: 502 });

    const headers = new Headers();
    headers.set('Content-Type', upstream.headers.get('Content-Type') || 'video/mp4');
    headers.set('Access-Control-Allow-Origin', '*');
    headers.set('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(filename)}`);
    const cl = upstream.headers.get('Content-Length');
    if (cl) headers.set('Content-Length', cl);

    return new Response(upstream.body, { status: 200, headers });
  } catch (e) {
    return new Response('proxy error: ' + e.message, { status: 500 });
  }
}

// ===================== Worker 入口 =====================

export default {
  async fetch(request) {
    if (request.method === 'OPTIONS') {
      return new Response(null, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type',
          'Access-Control-Max-Age': '86400',
        },
      });
    }

    const path = new URL(request.url).pathname;
    if (path === '/api/video-info') return handleVideoInfo(request);
    if (path === '/api/dl-stream')  return handleDlStream(request);
    if (path === '/api/test-browser') return handleTestBrowser(request);

    if (path === '/' || path === '/health') {
      return json({
        status: 'ok',
        timestamp: new Date().toISOString(),
        platforms: ['douyin', 'xiaohongshu', 'tiktok', 'youtube'],
        note: '抖音走 a-bogus 純算簽名',
        browser_rendering: typeof BROWSER !== 'undefined' ? 'available' : 'not bound',
      });
    }

    return json({ error: 'Not Found' }, 404);
  },
};

// ===================== Browser Rendering 測試 =====================

async function handleTestBrowser(request) {
  // BROWSER 是 Worker 的 env binding
  // 如果沒綁就會出錯
  let browser;
  try {
    browser = globalThis.BROWSER || BROWSER;
  } catch (e) {
    return json({
      success: false,
      error: 'BROWSER binding 沒綁',
      hint: '要 wrangler.toml 加上 browser = { binding = "BROWSER" } 並升級到 Paid Plan',
    }, 503);
  }

  if (!browser) {
    return json({
      success: false,
      error: 'BROWSER = undefined',
      hint: '帳號沒升級到 Workers Paid Plan，或 Browser Rendering 沒開通',
    }, 503);
  }

  const url = new URL(request.url);
  const targetUrl = url.searchParams.get('url') || 'https://example.com';

  try {
    const session = await browser.newSession({ browser: { type: 'chromium' } });
    try {
      const page = await session.newPage();
      await page.goto(targetUrl, { waitUntil: 'networkidle0', timeout: 30000 });
      await new Promise(r => setTimeout(r, 5000));

      const result = await page.evaluate(() => {
        const videos = [];
        document.querySelectorAll('video').forEach(v => {
          if (v.src) videos.push(v.src);
          if (v.currentSrc) videos.push(v.currentSrc);
          v.querySelectorAll('source').forEach(s => { if (s.src) videos.push(s.src); });
        });
        const perfVideos = [];
        performance.getEntriesByType('resource').forEach(e => {
          if (/\.mp4|m3u8/.test(e.name)) perfVideos.push(e.name);
        });
        return {
          videoElements: videos,
          perfVideos: perfVideos.slice(0, 10),
          title: document.title,
          finalUrl: location.href,
        };
      });

      await session.close();

      return json({ success: true, target: targetUrl, result });
    } catch (e) {
      await session.close().catch(() => {});
      throw e;
    }
  } catch (e) {
    return json({
      success: false,
      error: 'Browser Rendering 執行失敗',
      message: e.message,
      stack: e.stack,
    }, 500);
  }
}
